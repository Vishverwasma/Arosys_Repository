package com.app.JobSchedular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobSchedularApplicationTests {

	@Test
	void contextLoads() {
	}

}

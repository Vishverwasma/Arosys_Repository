package com.app.JobSchedular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobSchedularApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobSchedularApplication.class, args);
	}

}

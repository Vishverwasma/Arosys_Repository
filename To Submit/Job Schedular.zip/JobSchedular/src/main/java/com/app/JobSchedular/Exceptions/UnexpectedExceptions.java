package com.app.JobSchedular.Exceptions;

public class UnexpectedExceptions extends Exception{
	public UnexpectedExceptions(String message) {
		super(message);
	}
}

package com.app.JobSchedulerApplication.Exception;

public class UnexpectedException extends Throwable {
	public UnexpectedException(String message) {
		super(message);
	}
}
